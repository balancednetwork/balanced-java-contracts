from .sicx import StakedICX
