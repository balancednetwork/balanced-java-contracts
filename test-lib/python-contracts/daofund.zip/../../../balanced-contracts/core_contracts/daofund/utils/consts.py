ADDRESS_DICT = {"sICX": "cx2609b924e33ef00b648a409245c7ea394c467824",
                "bnUSD": "cx88fd7df7ddff82f7cc735c871dc519838cb235bb",
                "BALN": "cxf61cd5a45dc9f91c15aa65831a30a90d59a09619",
                "USDS": "cxbb2871f468a3008f80b08fdde5b8b951583acf06",
                "IUSDC": "cxae3034235540b924dfcc1b45836c293dcc82bfb7",
                "OMM": "cx1a29259a59f463a67bb2ef84398b30ca56b5830a"
                }
