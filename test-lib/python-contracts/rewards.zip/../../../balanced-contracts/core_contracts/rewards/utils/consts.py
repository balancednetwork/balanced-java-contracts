from iconservice import *

TAG = 'BalancedRewards'

EXA = 10**18

DATASOURCE_DB_PREFIX = b'datasource'
DAY_IN_MICROSECONDS = 86400 * (10 ** 6)
DEFAULT_BATCH_SIZE = 50
